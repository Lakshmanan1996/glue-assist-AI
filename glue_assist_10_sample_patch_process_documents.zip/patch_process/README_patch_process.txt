GLUE ASSIST AI - 10 SAMPLE PATCH PROCESS DOCUMENTS
===================================================

These 10 fictional customer patch SOPs are designed to complement the 10 sample Ticket Process SOPs.

All customer names, schedules, time zones, contacts (where any), and exceptions are synthetic lab examples. They are NOT approved customer procedures and must never be used for real production patching.

The samples intentionally vary:
- Server patch frequency and maintenance windows
- Workstation patch windows and automated reboot times
- Whether reboot approval is required
- Device-specific exclusions and exceptions
- Site, shift, event, and time-zone considerations
- Documentation and escalation requirements

Customer mapping:
1. Northstar Manufacturing
2. BluePeak Healthcare
3. Summit Education Group
4. Redwood Legal Services
5. Cedar Retail
6. Evergreen Financial
7. Oceanview Hospitality
8. Pioneer Logistics
9. Silverline Media
10. Westbridge Property Group

RAG lab objective:
Ask a question with a customer name and retrieve only that customer's patch policy. The assistant must distinguish server rules from workstation rules and must apply the correct exception. If the source document does not answer a question, the assistant must say the information is not specified.
