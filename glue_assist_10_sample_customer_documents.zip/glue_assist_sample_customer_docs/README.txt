GLUE ASSIST AI - SAMPLE CUSTOMER KNOWLEDGE DOCUMENTS
=====================================================

This package contains 10 fictional customer SOP documents for a RAG lab.

IMPORTANT:
- Every customer, contact, phone number, email address, and procedure variation in these samples is synthetic.
- These are training/test examples only. They are NOT approved operational procedures.
- Do not use them to handle real customer incidents.
- Replace them only with customer-approved documents after authorization and security review.
- Customer separation and tenant authorization must be enforced by the backend before real multi-customer RAG is enabled.

Files:
1. Northstar Manufacturing
2. BluePeak Healthcare
3. Summit Education Group
4. Redwood Legal Services
5. Cedar Retail
6. Evergreen Financial
7. Oceanview Hospitality
8. Pioneer Logistics
9. Silverline Media
10. Westbridge Property Group

Suggested lab test questions:
- What is the Critical escalation order for Northstar Manufacturing?
- Can BluePeak Healthcare clinical application servers be rebooted without approval?
- What are Summit Education's workstation support hours?
- What is the reboot approval rule for Evergreen Financial?
- Which actions are prohibited for Cedar Retail payment infrastructure?
- What maintenance information must be checked for Pioneer Logistics?

RAG test objective:
The assistant should retrieve only the relevant customer's document, answer from the retrieved text, and say when the document does not contain the requested information.
